/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.siakad.forms;

import com.app.siakad.database.AutoFitTableColumns;
import com.app.siakad.database.KoneksiDB;
import com.app.siakad.entities.Dosen;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DEVI
 */
public class IfrDosen extends javax.swing.JInternalFrame {
   Dosen dosen = new Dosen();
    
    public IfrDosen() {
        initComponents();
        
        clearInput(); disableInput(); setTabelDosen(); showDataDosen();
    }
    
    private void clearInput(){
            txtNIK.setText("");
            txtKdDosen.setText("");
            txtNip.setText("");
            txtNamaPegawai.setText("");
            cmbJnsKel.setSelectedIndex(0);
            txtTmpLahir.setText("");
            dtTglLahir.setDate(new Date());
            txtAgama.setText("");
            txtAlamat.setText("");
            txtNoTelepon1.setText("");
            txtNoTelepon2.setText("");
            txtEmail.setText("");
            dtTanggalMulaiTugas.setDate(new Date());
            txtNamaIbu.setText("");
            cmbStaMenikah.setSelectedIndex(0);
            txtJmlTanggungan.setText("");
            cmbStatusPeg.setSelectedIndex(0);
            cmbStaAktif.setSelectedIndex(0);
            btnTambah.setText("Tambah");
            btnSimpan.setText("Simpan");
            btnTambah.setIcon(new javax.swing.ImageIcon(getClass().
                    getResource("/com/app/siakad/icons/icons8_Add_List_20px.png")));
        }
    
    private void disableInput(){
            txtNIK.setEnabled(false);
            txtKdDosen.setEnabled(false);
            txtNip.setEnabled(false);
            txtNamaPegawai.setEnabled(false);
            cmbJnsKel.setEnabled(false);
            txtTmpLahir.setEnabled(false);
            dtTglLahir.setEnabled(false);
            txtAgama.setEnabled(false);
            txtAlamat.setEnabled(false);
            txtNoTelepon1.setEnabled(false);
            txtNoTelepon2.setEnabled(false);
            txtEmail.setEnabled(false);
            dtTanggalMulaiTugas.setEnabled(false);
            txtNamaIbu.setEnabled(false);
            cmbStaMenikah.setEnabled(false);
            txtJmlTanggungan.setEnabled(false);
            cmbStatusPeg.setEnabled(false);
            cmbStaAktif.setEnabled(false);
            btnSimpan.setEnabled(false);
            btnHapus.setEnabled(false);
    }
    
    private void enableInput(){
            txtNIK.setEnabled(true);
            txtKdDosen.setEnabled(true);
            txtNip.setEnabled(true);
            txtNamaPegawai.setEnabled(true);
            cmbJnsKel.setEnabled(true);
            txtTmpLahir.setEnabled(true);
            dtTglLahir.setEnabled(true);
            txtAgama.setEnabled(true);
            txtAlamat.setEnabled(true);
            txtNoTelepon1.setEnabled(true);
            txtNoTelepon2.setEnabled(true);
            txtEmail.setEnabled(true);
            dtTanggalMulaiTugas.setEnabled(true);
            txtNamaIbu.setEnabled(true);
            cmbStaMenikah.setEnabled(true);
            txtJmlTanggungan.setEnabled(true);
            cmbStatusPeg.setEnabled(true);
            cmbStaAktif.setEnabled(true);
            btnSimpan.setEnabled(true);
     
    }
    
    private void setTabelDosen(){
            String[] kolom1 = {"NIK", "Kode_Dosen", "Nip", "Nama Pegawai", "L/P", 
                                "Tempat", "Tgl. Lahir", "Agama", "Alamat", 
                                "No. Telepon1", "No. Telepon2", "Email", "Tempat", 
                                "Nama Ibu", "Status Menikah", "Jumlah Tanggungan",
                                "Status Pegawai", "Aktif/Tidak Aktif"};
            dosen.tbldosen = new DefaultTableModel(null, kolom1){
                Class[] types = new Class[]{
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class,
                    java.lang.String.class
                };
                public Class getColumnClass(int columnIndex){
                return types [columnIndex];
            }
                public boolean isCellEditable(int row, int col){
                int cola = dosen.tbldosen.getColumnCount();
                return (col < cola) ? false :true;
            }
          };
            tbDataDosen.setModel(dosen.tbldosen);
            tbDataDosen.getColumnModel().getColumn(0).setPreferredWidth(75);
            tbDataDosen.getColumnModel().getColumn(1).setPreferredWidth(225);
            tbDataDosen.getColumnModel().getColumn(2).setPreferredWidth(75);
            tbDataDosen.getColumnModel().getColumn(3).setPreferredWidth(300);
            tbDataDosen.getColumnModel().getColumn(4).setPreferredWidth(75);
            tbDataDosen.getColumnModel().getColumn(5).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(6).setPreferredWidth(300);
            tbDataDosen.getColumnModel().getColumn(7).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(8).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(9).setPreferredWidth(300);
            tbDataDosen.getColumnModel().getColumn(10).setPreferredWidth(300);
            tbDataDosen.getColumnModel().getColumn(11).setPreferredWidth(125);
            tbDataDosen.getColumnModel().getColumn(12).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(13).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(14).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(15).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(16).setPreferredWidth(150);
            tbDataDosen.getColumnModel().getColumn(17).setPreferredWidth(150);
        }
    
    public void showDataDosen(){
        tbDataDosen.setModel(dosen.tbldosen);
        int row = dosen.tbldosen.getRowCount();
        for(int i=0; i<row; i++){
            dosen.tbldosen.removeRow(0);              //mengosongkan isi tabel
        }
        dosen.select();                                    //utk memanggil method select
        dosen.list.forEach((obj) -> {
            dosen.tblthangkatan.addRow((Object[]) obj);
        });
        tbDataDosen.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        AutoFitTableColumns tca = new AutoFitTableColumns(tbDataDosen);
        tca.adjustColumns();
        lbRecord.setText("Record : " + tbDataDosen.getRowCount());
    }
    
     public void aksiSimpan(){
        if(txtNIK.getText().equals("") || txtKdDosen.getText().equals("") || txtNip.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Mohon lengkapi data",
                    "Informasi", JOptionPane.INFORMATION_MESSAGE);
        }else{
            dosen.isUpdate = !btnSimpan.getText().equals("Simpan");
            dosen.nik = txtNIK.getText();
            dosen.kd_dosen = txtKdDosen.getText();
            dosen.nip = txtNip.getText();
            dosen.nama_pegawai = txtNamaPegawai.getText();
            dosen.jk = (String) cmbJnsKel.getSelectedItem();
            dosen.tmp_lahir = txtTmpLahir.getText();
            dosen.tgl_lahir = dosen.tglinput.format(dtTglLahir.getDate());
            dosen.agama = txtAgama.getText();
            dosen.alamat = txtAlamat.getText();
            dosen.no_telepon1 = txtNoTelepon1.getText();
            dosen.no_telepon2 = txtNoTelepon2.getText();
            dosen.email = txtEmail.getText();
            dosen.tmt = dosen.tglinput.format(dtTanggalMulaiTugas.getDate());
            dosen.nama_ibu = txtNamaIbu.getText();
            dosen.sta_menikah = cmbStaMenikah.getSelectedItem().toString();
            dosen.jml_tanggungan = Integer.parseInt(txtJmlTanggungan.getText());
            dosen.sta_pegawai = cmbStatusPeg.getSelectedItem().toString(); 
            dosen.sta_aktif = cmbStaAktif.getSelectedItem().toString();
            
            dosen.insert_update();
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan",
                    "Informasi", JOptionPane.INFORMATION_MESSAGE);
            clearInput(); disableInput(); showDataDosen();
        }
     }
     
     private void aksiHapus(){
        if(txtNIK.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Informasi",
                    "Anda belum memilih data yang akan dihapus", JOptionPane.INFORMATION_MESSAGE);
        }else{
            int jawab = JOptionPane.showConfirmDialog(this, "Apakah Anda akan menghapus data ini? Kode "+dosen.nik,
                    "Konfirmasi",JOptionPane.YES_NO_OPTION);
            if(jawab == JOptionPane.YES_OPTION){
                dosen.delete(dosen.nik);
                JOptionPane.showMessageDialog(this, "Data berhasil dihapus",
                        "Informasi", JOptionPane.INFORMATION_MESSAGE);
                clearInput(); disableInput(); showDataDosen();
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        txtNIK = new javax.swing.JTextField();
        txtKdDosen = new javax.swing.JTextField();
        txtNip = new javax.swing.JTextField();
        txtNamaPegawai = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAlamat = new javax.swing.JEditorPane();
        txtAgama = new javax.swing.JTextField();
        txtNoTelepon1 = new javax.swing.JTextField();
        txtNoTelepon2 = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtNamaIbu = new javax.swing.JTextField();
        cmbStaMenikah = new javax.swing.JComboBox<>();
        txtJmlTanggungan = new javax.swing.JTextField();
        cmbStaAktif = new javax.swing.JComboBox<>();
        txtTmpLahir = new javax.swing.JTextField();
        dtTglLahir = new com.toedter.calendar.JDateChooser();
        dtTglMulTug = new javax.swing.JPanel();
        dtTanggalMulaiTugas = new com.toedter.calendar.JDateChooser();
        cmbJnsKel = new javax.swing.JComboBox<>();
        cmbStatusPeg = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        txtCari = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        btnTambah = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbDataDosen = new javax.swing.JTable();
        lbRecord = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setClosable(true);
        setTitle(".: Form Dosen");
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/Admin-Schoolar-Icon.png"))); // NOI18N

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/logo-medium.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        jLabel2.setText("FORM DOSEN");

        jLabel3.setText("Form ini digunakan untuk mengolah data Dosen");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Input Data : "));

        txtNIK.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nik :"));
        txtNIK.setOpaque(false);

        txtKdDosen.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Kode Dosen"));
        txtKdDosen.setOpaque(false);

        txtNip.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nip :"));
        txtNip.setOpaque(false);

        txtNamaPegawai.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nama Pegawai :"));
        txtNamaPegawai.setOpaque(false);

        txtAlamat.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Alamat :"));
        txtAlamat.setOpaque(false);
        jScrollPane3.setViewportView(txtAlamat);

        txtAgama.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Agama :"));
        txtAgama.setOpaque(false);

        txtNoTelepon1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "No. Telepon1 :"));
        txtNoTelepon1.setOpaque(false);

        txtNoTelepon2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "No. Telepon2 :"));
        txtNoTelepon2.setOpaque(false);
        txtNoTelepon2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNoTelepon2ActionPerformed(evt);
            }
        });

        txtEmail.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Email :"));
        txtEmail.setOpaque(false);

        txtNamaIbu.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nama Ibu :"));
        txtNamaIbu.setOpaque(false);
        txtNamaIbu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaIbuActionPerformed(evt);
            }
        });

        cmbStaMenikah.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "Belum Menikah", "Sudah Menikah", "Pernah Menikah" }));
        cmbStaMenikah.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Status Menikah :"));
        cmbStaMenikah.setOpaque(false);

        txtJmlTanggungan.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Jumlah Tanggungan :"));
        txtJmlTanggungan.setOpaque(false);

        cmbStaAktif.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih--", "Aktif", "Tidak Aktif" }));
        cmbStaAktif.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Status Aktif :"));

        txtTmpLahir.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Tempat Lahir"));
        txtTmpLahir.setOpaque(false);

        dtTglLahir.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Tanggal lahir : "));

        dtTglMulTug.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Tanggal Mulai Tugas :"));

        javax.swing.GroupLayout dtTglMulTugLayout = new javax.swing.GroupLayout(dtTglMulTug);
        dtTglMulTug.setLayout(dtTglMulTugLayout);
        dtTglMulTugLayout.setHorizontalGroup(
            dtTglMulTugLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dtTanggalMulaiTugas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        dtTglMulTugLayout.setVerticalGroup(
            dtTglMulTugLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dtTglMulTugLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(dtTanggalMulaiTugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        cmbJnsKel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "Laki - Laki", "Perempuan" }));
        cmbJnsKel.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Jenis Kelamis : "));
        cmbJnsKel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbJnsKelActionPerformed(evt);
            }
        });

        cmbStatusPeg.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbStatusPeg.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Status Pegawai : "));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                    .addComponent(txtNIK, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtTmpLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(dtTglLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(txtAgama, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(txtNoTelepon1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(txtNoTelepon2, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(txtEmail))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(dtTglMulTug, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtKdDosen, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE))
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtNip, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(txtNamaPegawai, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(cmbJnsKel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtNamaIbu, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(cmbStaMenikah, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(txtJmlTanggungan, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbStatusPeg, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cmbStaAktif, 0, 136, Short.MAX_VALUE)))))
                .addGap(1, 1, 1))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNIK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNip, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNamaPegawai, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtKdDosen, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmbJnsKel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtNoTelepon1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtNoTelepon2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtAgama, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtTmpLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dtTglLahir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtNamaIbu, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbStaMenikah, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cmbStaAktif, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtJmlTanggungan, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(dtTglMulTug, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbStatusPeg)))
                    .addComponent(jScrollPane3))
                .addGap(1, 1, 1))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Cari :"));
        jPanel2.setOpaque(false);

        txtCari.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Kode Dosen :"));
        txtCari.setOpaque(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 7, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Navigasi :"));

        btnTambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/trans-add.png"))); // NOI18N
        btnTambah.setText("Tambah");
        btnTambah.setOpaque(false);
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnSimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/save-black.png"))); // NOI18N
        btnSimpan.setText("Simpan");
        btnSimpan.setOpaque(false);
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        btnHapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/trans-hapus.png"))); // NOI18N
        btnHapus.setText("Hapus");
        btnHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHapusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 7, Short.MAX_VALUE))
        );

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Data tabel form dosen : "));

        tbDataDosen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nik", "Kode Dosen", "Nip", "Nama Pegawai", "Jenis Kelamin", "Alamat", "Tempat Lahir", "Tanggal Lahir", "Agama", "No.Telepon1", "No.Telepon2", "Email", "Tempat", "Nama Ibu", "Status Menikah", "Jumlah Tanggungan", "Status Pegawai", "Status Aktif"
            }
        ));
        tbDataDosen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbDataDosenMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbDataDosen);

        lbRecord.setText("Record 0");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(1, 1, 1)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(lbRecord)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(jLabel3))
                    .addComponent(jLabel1))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(1, 1, 1)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(lbRecord))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        aksiHapus();
    }//GEN-LAST:event_btnHapusActionPerformed

    private void txtNamaIbuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaIbuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaIbuActionPerformed

    private void txtNoTelepon2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNoTelepon2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNoTelepon2ActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        if(btnTambah.getText().equals("Tambah")){
            clearInput();
            enableInput();
            btnTambah.setText("Batal");
            txtNIK.requestFocus(true);
            btnTambah.setIcon(new javax.swing.ImageIcon(getClass().
                    getResource("/com/app/siakad/icons/btn_delete.png")));
        }else {
            
            clearInput();
            disableInput();
            btnTambah.setText("Tambah");
            btnTambah.setIcon(new javax.swing.ImageIcon(getClass().
                    getResource("/com/app/siakad/icons/icons8_Add_List_20px.png")));
            
        }
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        aksiSimpan();
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void tbDataDosenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbDataDosenMouseClicked
       /* if(evt.getClickCount() == 2){
            int row = tbDataDosen.getSelectedRow();
            dosen.kd_dosen = Integer.parseInt(tbDataDosen.getValueAt(row, 0).toString());
            dosen.nik = Integer.parseInt(tbDataDosen.getValueAt(row, 1).toString());

            txtKdDosen.setText(Integer.toString(dosen.kd_dosen));
            txtNIK.setText(Integer.toString(dosen.nik));
            enableInput();
            txtKdDosen.setEnabled(false);
            btnHapus.setEnabled(true);
            btnSimpan.setText("Ubah");

        }*/
    }//GEN-LAST:event_tbDataDosenMouseClicked

    private void cmbJnsKelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbJnsKelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbJnsKelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JComboBox<String> cmbJnsKel;
    private javax.swing.JComboBox<String> cmbStaAktif;
    private javax.swing.JComboBox<String> cmbStaMenikah;
    private javax.swing.JComboBox<String> cmbStatusPeg;
    private com.toedter.calendar.JDateChooser dtTanggalMulaiTugas;
    private com.toedter.calendar.JDateChooser dtTglLahir;
    private javax.swing.JPanel dtTglMulTug;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbRecord;
    private javax.swing.JTable tbDataDosen;
    private javax.swing.JTextField txtAgama;
    private javax.swing.JEditorPane txtAlamat;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtJmlTanggungan;
    private javax.swing.JTextField txtKdDosen;
    private javax.swing.JTextField txtNIK;
    private javax.swing.JTextField txtNamaIbu;
    private javax.swing.JTextField txtNamaPegawai;
    private javax.swing.JTextField txtNip;
    private javax.swing.JTextField txtNoTelepon1;
    private javax.swing.JTextField txtNoTelepon2;
    private javax.swing.JTextField txtTmpLahir;
    // End of variables declaration//GEN-END:variables
}