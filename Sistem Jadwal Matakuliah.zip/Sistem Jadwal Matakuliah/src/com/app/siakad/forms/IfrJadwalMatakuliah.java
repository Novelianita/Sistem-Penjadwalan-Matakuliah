/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.siakad.Forms;

import com.app.siakad.database.KoneksiDB;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ritky
 */
public class IfrJadwalMatakuliah extends javax.swing.JInternalFrame {
    
    KoneksiDB getCnn = new KoneksiDB();     //deklarasi Object untuk koneksi Database
    Connection _Cnn;
    
    // deklarasikan variabel yang dibutuhkan
    
    String sqlselect, sqlinsert, sqldelete ;
    String vid_tk, vsemester, vkd_prodi, vid_kelas, kat_kelas, vhari, id_sj, vkd_mk, vkd_dosen, vkd_ruang ;
    
    private DefaultTableModel tbJadwalMatakuliah ;
    SimpleDateFormat tglinput = new SimpleDateFormat ("yyyy,MM,dd");
    SimpleDateFormat tglview = new SimpleDateFormat ("dd,MM,yyyy");
    private DefaultTableModel tbljadwalmatakuliah;
    
    /**
     * Creates new form IfrJadwalMatakuliah
     */
    public IfrJadwalMatakuliah() {
        initComponents();
    }
    
    private void clearInput(){
        cmbThnAjaran.setSelectedIndex(0);
        cmbSemester.setSelectedIndex(0);
        cmbProdi.setSelectedIndex(0);
        cmbKtgKls.setSelectedIndex(0);
        cmbHari.setSelectedIndex(0);
        txtJam.setText("");
        cmbNmMatKul.setSelectedIndex(0);
        cmbNmDosen.setSelectedIndex(0);
        cmbNmRuang.setSelectedIndex(0);
        btnSimpan.setText("Simpan");
        
    }
    private void setTableJadwalMatakuliah(){
        String[] kolom1 = {"Tahun ajaran", "Semester", "Prodi", "Kategori Kelas", "Hari",
            "Jam", "Nama Matakuliah", "Nama Dosen", "Nama Ruang"};
        tbljadwalmatakuliah = new DefaultTableModel(null, kolom1){
            Class[] types = new Class[]{
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class,
                java.lang.String.class
            };
            public Class getColumnClass (int columnIndex){
                return types [columnIndex];
            }
            //Agar tabel tidak bisa diEdit
            public boolean isCellEditable(int row, int col){
                int colla = tbljadwalmatakuliah.getColumnCount();
                return (col < colla) ? false : true ;
            }
        };
        tbDataJadwalMatakuliah.setModel(tbljadwalmatakuliah);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(0).setPreferredWidth(75);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(1).setPreferredWidth(250);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(2).setPreferredWidth(25);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(3).setPreferredWidth(175);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(4).setPreferredWidth(75);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(5).setPreferredWidth(75);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(6).setPreferredWidth(175);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(7).setPreferredWidth(300);
        tbDataJadwalMatakuliah.getColumnModel().getColumn(8).setPreferredWidth(275);
    }
    
    private void clearTableJadwalMatakuliah(){
        int row = tbljadwalmatakuliah.getRowCount();
        for(int i=0; i<row; i++){
            tbljadwalmatakuliah.removeRow(0);
        }
    }
    private void showDataJadwalMatakuliah(){
        try{
            _Cnn = null;
            _Cnn = getCnn.getConnection();
            
            // Di sini belum di masukan nama atribut pada jadwal matakuliah
            
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(this, "Error Method showJadwalMatakuliah() : "+ex);
        }
    }
    private void getJadwalMatakuliah(){
        
    }
    
    String[] KeyTK ;
    private void listTK(){
        
    }
    String[] KeyProdi;
    private void listProdi(){
        
    }
    String[] KeyKelas;
    private void listKelas(){
        
    }
    String[] KeySJ;
    private void listSJ(){
        
    }
    String[] KeyMK;
    private void listMK(){
        
    }
    String[] KeyDosen;
    private void listDosen(){
        
    }
    String[] KeyRuang;
    private void listRuang(){
        
    }
    private void aksiSimpan(){
        
    }
    private void aksiHapus(){
        
    }
    private void aksiKeluar(){
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbDataJadwalMatakuliah = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        panelAlpha21 = new com.app.siakad.forms.PanelAlpha2();
        cmbThnAjaran = new javax.swing.JComboBox<>();
        cmbSemester = new javax.swing.JComboBox<>();
        cmbProdi = new javax.swing.JComboBox<>();
        cmbKtgKls = new javax.swing.JComboBox<>();
        cmbHari = new javax.swing.JComboBox<>();
        txtJam = new javax.swing.JTextField();
        cmbNmMatKul = new javax.swing.JComboBox<>();
        cmbNmDosen = new javax.swing.JComboBox<>();
        cmbNmRuang = new javax.swing.JComboBox<>();
        panelAlpha22 = new com.app.siakad.forms.PanelAlpha2();
        btnTambah = new javax.swing.JButton();
        btnSimpan = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();

        setBackground(new java.awt.Color(51, 204, 0));
        setClosable(true);
        setTitle(".: Jadwal Matakuliah");
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/Admin-Schoolar-Icon.png"))); // NOI18N

        jLabel1.setText("Record 0");

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Tabel Data Tahun Ajaran : Klik 2x untuk mengubah/menghapus data"));

        tbDataJadwalMatakuliah.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tbDataJadwalMatakuliah.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tahun Ajaran", "Semester", "Prodi", "Kategori Kelas", "Hari", "Jam", "Nama Matakuliah", "Nama Dosen", "Nama Ruang"
            }
        ));
        jScrollPane2.setViewportView(tbDataJadwalMatakuliah);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/logo-medium.png"))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Arial", 3, 14)); // NOI18N
        jLabel3.setText("FORM JADWAL MATAKULIAH");

        jLabel4.setText("Form ini  digunakan untuk input jadwal matakuliah");

        panelAlpha21.setBorder(javax.swing.BorderFactory.createTitledBorder("Input : "));

        cmbThnAjaran.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " --- Pilih ---" }));
        cmbThnAjaran.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Tahun Ajaran :"));
        cmbThnAjaran.setOpaque(false);

        cmbSemester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --" }));
        cmbSemester.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Semester : "));

        cmbProdi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " -- Pilih --", "Teknik Informatika", "Teknik Kimia", "Teknik Mesin" }));
        cmbProdi.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Prodi :"));
        cmbProdi.setOpaque(false);

        cmbKtgKls.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " -- Pilih --" }));
        cmbKtgKls.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Kategori Kelas :"));
        cmbKtgKls.setOpaque(false);

        cmbHari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "Senin", "Selasa", "Rabu", "Kamis", "Jumat" }));
        cmbHari.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Hari :"));
        cmbHari.setOpaque(false);

        txtJam.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Jam :"));
        txtJam.setOpaque(false);

        cmbNmMatKul.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "Pemrogaman", "Proyek 3", "Arkom", "Basis Data" }));
        cmbNmMatKul.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nama Matakuliah :"));
        cmbNmMatKul.setOpaque(false);
        cmbNmMatKul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbNmMatKulActionPerformed(evt);
            }
        });

        cmbNmDosen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " -- Pilih --", "Anom Sejogati, S.Kom", "M. Rizaludin, M.Kom", "Imam Prayogo Pujiono, S.Kom" }));
        cmbNmDosen.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nama Dosen :"));
        cmbNmDosen.setOpaque(false);
        cmbNmDosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbNmDosenActionPerformed(evt);
            }
        });

        cmbNmRuang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- Pilih --", "Teori", "Lab 1", "Lab 2" }));
        cmbNmRuang.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), "Nama Ruang :"));
        cmbNmRuang.setOpaque(false);

        javax.swing.GroupLayout panelAlpha21Layout = new javax.swing.GroupLayout(panelAlpha21);
        panelAlpha21.setLayout(panelAlpha21Layout);
        panelAlpha21Layout.setHorizontalGroup(
            panelAlpha21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlpha21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelAlpha21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelAlpha21Layout.createSequentialGroup()
                        .addComponent(cmbThnAjaran, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbSemester, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbProdi, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbKtgKls, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbHari, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelAlpha21Layout.createSequentialGroup()
                        .addComponent(txtJam, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbNmMatKul, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbNmDosen, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbNmRuang, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelAlpha21Layout.setVerticalGroup(
            panelAlpha21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlpha21Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(panelAlpha21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbThnAjaran, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbSemester, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbProdi, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbKtgKls, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbHari, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelAlpha21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtJam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbNmMatKul, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbNmDosen, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbNmRuang, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5))
        );

        panelAlpha22.setBorder(javax.swing.BorderFactory.createTitledBorder("Navigasi : "));

        btnTambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/trans-add.png"))); // NOI18N
        btnTambah.setText("Tambah");
        btnTambah.setOpaque(false);

        btnSimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/save-black.png"))); // NOI18N
        btnSimpan.setText("Simpan");

        btnHapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/trans-hapus.png"))); // NOI18N
        btnHapus.setText("Hapus");

        btnKeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/app/siakad/icons/close.png"))); // NOI18N
        btnKeluar.setText("Keluar");

        javax.swing.GroupLayout panelAlpha22Layout = new javax.swing.GroupLayout(panelAlpha22);
        panelAlpha22.setLayout(panelAlpha22Layout);
        panelAlpha22Layout.setHorizontalGroup(
            panelAlpha22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlpha22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelAlpha22Layout.setVerticalGroup(
            panelAlpha22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlpha22Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(panelAlpha22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambah, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(btnSimpan, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(btnHapus, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(btnKeluar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addGap(5, 5, 5))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(20, 20, 20))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelAlpha21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelAlpha22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)))
                .addGap(5, 5, 5))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(1, 1, 1)
                        .addComponent(jLabel4)
                        .addGap(13, 13, 13))
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(panelAlpha21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAlpha22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbNmMatKulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbNmMatKulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbNmMatKulActionPerformed

    private void cmbNmDosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbNmDosenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbNmDosenActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JComboBox<String> cmbHari;
    private javax.swing.JComboBox<String> cmbKtgKls;
    private javax.swing.JComboBox<String> cmbNmDosen;
    private javax.swing.JComboBox<String> cmbNmMatKul;
    private javax.swing.JComboBox<String> cmbNmRuang;
    private javax.swing.JComboBox<String> cmbProdi;
    private javax.swing.JComboBox<String> cmbSemester;
    private javax.swing.JComboBox<String> cmbThnAjaran;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    private com.app.siakad.forms.PanelAlpha2 panelAlpha21;
    private com.app.siakad.forms.PanelAlpha2 panelAlpha22;
    private javax.swing.JTable tbDataJadwalMatakuliah;
    private javax.swing.JTextField txtJam;
    // End of variables declaration//GEN-END:variables
}
